$(function () {
	
	$("#btn-menu").click(function(){
		$(this).toggleClass("menu-open");
		$("#dashboard").toggleClass("hide");
		$("section.active").toggleClass("open");
	});

	$("#btn-edit .menu-toggle").click(function(){
		$(this).parents("#btn-edit").toggleClass("open");
	});

	$("#btn-user .menu-toggle").click(function(){
		$(this).parents("#btn-user").toggleClass("open");
	});

	$("#btn-edit .menu-item").click(function(){
		$("#box").addClass("open");
	});

	$("#box > icon[size='50tr']").click( function(){
		$("#box").removeClass("open");
	})

	$("section > aside > icon").click(function(){
		currentwin = $(this).parents("section").attr("flap");
		$(this).parents("section").remove();
		for (var i = currentwin; i < 10; i++) {
			$("section[flap='" + i + "']").attr("flap", i-1);
		}
	})

	$("section").not("icon[ic='cross-grey']").click(function(){
		$("section").removeClass("active");
		$(this).addClass("open").addClass("active");
		$("#btn-menu").toggleClass("menu-open");
		$("#dashboard").toggleClass("hide");
		var currentwin = $(this).attr("flap");
		if(currentwin == "1"){

		}
		else{
			for (var i = currentwin; i > 0; i--) {
				$("section[flap='" + i + "']").attr("flap", i+1);
			}
			$(this).attr("flap", 1);
		}
	});

});