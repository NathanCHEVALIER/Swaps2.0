<?php
	/*
	Bienvenue dans la liste Swaps des Insultes modérées automatiquement.
	Pour ajouter un mot, placer une berre verticale | (AltGr + 6) devant.
	Ne jamais faire de retour à la ligne avec la touche entrée mais avec le retour à la ligne automatique dans l'onglet Affichage de Notepad ++ et View de Sublim Text.
	
	Dernière modification par Nathan CHEVALIER le 2 Décembre 2016.
	*/
	
	$listeIMA = "FDP|fils de pute|connard";